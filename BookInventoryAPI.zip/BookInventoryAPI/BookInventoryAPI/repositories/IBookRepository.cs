﻿using BookInventoryAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookInventoryAPI.Repository
{
    public interface IBookRepository
    {
        Task<IEnumerable<BookModel>> GetAllBooksAsync();  // <-- Make sure this line exists
        Task<BookModel> GetBookByIdAsync(int id);
        Task AddBookAsync(BookModel book);
        Task UpdateBookAsync(BookModel book);
        Task DeleteBookAsync(int id);
    }
}
