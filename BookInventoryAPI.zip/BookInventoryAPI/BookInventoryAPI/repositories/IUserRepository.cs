﻿using System.Threading.Tasks;
using BookInventoryAPI.Models;

namespace BookInventoryAPI.Repository
{
    public interface IUserRepository
    {
        Task RegisterUserAsync(UserModel user);
        Task<UserModel> AuthenticateUserAsync(string username, string passwordHash);
        string GenerateToken(UserModel user);
    }
}
