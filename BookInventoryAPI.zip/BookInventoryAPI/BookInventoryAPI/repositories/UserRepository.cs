﻿using BookInventoryAPI.DataAccess;
using BookInventoryAPI.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BookInventoryAPI.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly ISqlDataAccess _db;
        private readonly IConfiguration _config;

        public UserRepository(ISqlDataAccess db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        public async Task RegisterUserAsync(UserModel user)
        {
            string sql = @"INSERT INTO Users (UserName, PasswordHash)
                           VALUES (@UserName, @PasswordHash)";
            await _db.SaveData(sql, user);
        }

        public async Task<UserModel> AuthenticateUserAsync(string username, string passwordHash)
        {
            string sql = @"SELECT Id, UserName, PasswordHash
                           FROM Users
                           WHERE UserName = @UserName AND PasswordHash = @PasswordHash";

            return (await _db.LoadData<UserModel, dynamic>(sql, new { UserName = username, PasswordHash = passwordHash })).FirstOrDefault();
        }

        public string GenerateToken(UserModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName)
            };

            var token = new JwtSecurityToken(
                _config["Jwt:Issuer"],
                _config["Jwt:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
