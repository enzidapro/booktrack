﻿using BookInventoryAPI.DataAccess;
using BookInventoryAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookInventoryAPI.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly ISqlDataAccess _db;

        public BookRepository(ISqlDataAccess db)
        {
            _db = db;
        }

        public async Task<IEnumerable<BookModel>> GetAllBooksAsync()
        {
            string sql = "SELECT * FROM Books";
            return await _db.LoadData<BookModel, dynamic>(sql, new { });
        }

        public async Task<BookModel> GetBookByIdAsync(int id)
        {
            string sql = "SELECT * FROM Books WHERE Id = @Id";
            return (await _db.LoadData<BookModel, dynamic>(sql, new { Id = id })).FirstOrDefault();
        }

        public async Task AddBookAsync(BookModel book)
        {
            string sql = @"INSERT INTO Books (Title, Author, ISBN, PublishedDate, Quantity)
                           VALUES (@Title, @Author, @ISBN, @PublishedDate, @Quantity)";
            await _db.SaveData(sql, book);
        }

        public async Task UpdateBookAsync(BookModel book)
        {
            string sql = @"UPDATE Books
                           SET Title = @Title, Author = @Author, ISBN = @ISBN, PublishedDate = @PublishedDate, Quantity = @Quantity
                           WHERE Id = @Id";
            await _db.SaveData(sql, book);
        }

        public async Task DeleteBookAsync(int id)
        {
            string sql = "DELETE FROM Books WHERE Id = @Id";
            await _db.SaveData(sql, new { Id = id });
        }
    }
}
