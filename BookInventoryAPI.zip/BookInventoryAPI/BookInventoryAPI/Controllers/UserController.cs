﻿using BookInventoryAPI.Models;
using BookInventoryAPI.Repository;
using Microsoft.AspNetCore.Mvc;

namespace BookInventoryAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        public UserController(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserModel user)
        {
            await _userRepository.RegisterUserAsync(user);
            return Ok("User registered successfully.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserModel user)
        {
            var authenticatedUser = await _userRepository.AuthenticateUserAsync(user.UserName, user.PasswordHash);

            if (authenticatedUser == null)
            {
                return Unauthorized("Invalid username or password.");
            }

            var token = _userRepository.GenerateToken(authenticatedUser);
            return Ok(new { Token = token });
        }
    }
}
